from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def kontak(request):
    return render(request, 'kontak.html')

def galeri(request):
    return render(request, 'galeri.html')
