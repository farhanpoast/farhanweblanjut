from django.contrib import admin
from django.urls import path
from mysite.views import index, kontak, galeri

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index),
    path('kontak/', kontak, name='kontak'),
    path('galeri/', galeri, name='galeri'),
]
